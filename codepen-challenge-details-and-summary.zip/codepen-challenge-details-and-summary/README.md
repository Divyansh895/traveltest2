# CodePen Challenge details and summary

A Pen created on CodePen.io. Original URL: [https://codepen.io/frogmcw/pen/deqRwa](https://codepen.io/frogmcw/pen/deqRwa).

#codepenchallenge using <details> & <summary>